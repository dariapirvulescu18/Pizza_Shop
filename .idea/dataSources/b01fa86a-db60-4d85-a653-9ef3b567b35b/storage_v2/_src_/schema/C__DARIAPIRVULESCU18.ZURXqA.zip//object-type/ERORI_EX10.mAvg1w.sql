create TYPE erori_ex10 AS OBJECT (v_error_message VARCHAR(300),
                               v_error_cod NUMBER(8));
/

