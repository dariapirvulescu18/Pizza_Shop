create TYPE full_name IS OBJECT(nume VARCHAR(25), prenume VARCHAR(25));
/

