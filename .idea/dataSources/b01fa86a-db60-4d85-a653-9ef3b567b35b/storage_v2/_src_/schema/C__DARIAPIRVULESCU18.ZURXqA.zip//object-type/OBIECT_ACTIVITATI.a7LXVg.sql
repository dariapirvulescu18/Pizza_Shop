create TYPE obiect_activitati IS OBJECT (id_ang NUMBER(4),
                                                    nume VARCHAR2(35),
                                                    productivitate VARCHAR2(35));
/

