create TYPE record_istoric AS OBJECT (
    prod VARCHAR2(25),
    data_prom DATE,
    sal NUMBER(8),
    nume VARCHAR2(25),
    prenume VARCHAR2(25)
);
/

