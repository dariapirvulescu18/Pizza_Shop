create TYPE trig_ldd_info_obj AS OBJECT (v_error_message VARCHAR(300),
                                                        v_error_cod NUMBER(8));
/

