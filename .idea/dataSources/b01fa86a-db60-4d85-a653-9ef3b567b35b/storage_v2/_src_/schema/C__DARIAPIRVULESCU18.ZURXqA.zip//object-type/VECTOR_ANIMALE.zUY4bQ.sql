create TYPE vector_animale IS VARRAY(15) OF animal.id_animal%TYPE;
/

