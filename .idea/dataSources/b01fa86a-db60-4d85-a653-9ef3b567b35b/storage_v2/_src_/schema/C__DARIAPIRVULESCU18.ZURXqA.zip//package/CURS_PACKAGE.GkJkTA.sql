create PACKAGE curs_package AS
  TYPE tip1 IS RECORD (
    nume VARCHAR2(50),
    varsta NUMBER
  );

  TYPE tip2 IS RECORD (
    adresa VARCHAR2(100),
    persoana tip1
  );

  TYPE tip3 IS RECORD (
    nume_companie VARCHAR2(100),
    client tip2
  );

  PROCEDURE update_sectoare;

  PROCEDURE display_sectoare_info;

  PROCEDURE query_casa;

  PROCEDURE query_facturi(p_status IN VARCHAR2);

  PROCEDURE update_products_price;
END curs_package;
/

