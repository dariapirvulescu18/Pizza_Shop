create PACKAGE BODY curs_package AS
  PROCEDURE update_sectoare IS
    v_tip3_info tip3;
    v_adresa VARCHAR2(100);
    v_nume VARCHAR2(50) := 'Nume Persoana';
    v_varsta NUMBER := 30;
  BEGIN
    v_adresa := 'Adresa Persoana';
    v_tip3_info := tip3('Nume Companie', (v_adresa, (v_nume, v_varsta)));

    UPDATE sectoare
    SET info_sector = v_tip3_info;
  END update_sectoare;

  PROCEDURE display_sectoare_info IS
  BEGIN
    FOR s IN (SELECT s.info_sector.nume_companie, 
                     s.info_sector.client.adresa, 
                     s.info_sector.client.persoana.nume, 
                     s.info_sector.client.persoana.varsta
              FROM sectoare s)
    LOOP
      DBMS_OUTPUT.PUT_LINE('Nume Companie: ' || s.nume_companie);
      DBMS_OUTPUT.PUT_LINE('Adresa: ' || s.adresa);
      DBMS_OUTPUT.PUT_LINE('Nume Persoana: ' || s.nume);
      DBMS_OUTPUT.PUT_LINE('Varsta Persoana: ' || s.varsta);
      DBMS_OUTPUT.PUT_LINE('--------------------------');
    END LOOP;
  END display_sectoare_info;

  PROCEDURE query_casa IS
    v_casa_id NUMBER := 1;
    v_casa_name VARCHAR2(50);
    v_total_facturi NUMBER;

    CURSOR casa_cursor (p_id_casa NUMBER) IS
        SELECT c.id_casa, c.nume, COUNT(f.id_factura) AS total_facturi
        FROM case c LEFT JOIN facturi f ON f.id_casa = c.id_casa
        WHERE c.id_casa = p_id_casa
        GROUP BY c.id_casa, c.nume;

  BEGIN
    OPEN casa_cursor(v_casa_id);

    LOOP
      FETCH casa_cursor INTO  v_casa_id, v_casa_name,  v_total_facturi;
      EXIT WHEN  casa_cursor%NOTFOUND;

      DBMS_OUTPUT.PUT_LINE('Casa: ' || v_casa_name);
      DBMS_OUTPUT.PUT_LINE('Total facturi: ' || v_total_facturi);
      DBMS_OUTPUT.PUT_LINE('--------------------------');
    END LOOP;

    CLOSE casa_cursor;
  END query_casa;

  PROCEDURE query_facturi(p_status IN VARCHAR2) IS
    TYPE my_cursor IS REF CURSOR;
    TYPE my_table IS TABLE OF facturi.status%TYPE;

    c my_cursor;
    tabel my_table;
    reusit BOOLEAN := FALSE;

    v_citit facturi.status%TYPE := p_status;
    v_data facturi.data%TYPE;
    v_status facturi.status%TYPE;
    v_id facturi.id_factura%TYPE;

  BEGIN
    SELECT DISTINCT (status)
    BULK COLLECT INTO tabel
    FROM facturi;

    FOR i IN tabel.FIRST .. tabel.LAST LOOP
      IF tabel(i) = v_citit THEN
        reusit := TRUE;
      END IF;
    END LOOP;

    IF reusit = TRUE THEN
      OPEN c FOR 'SELECT data, status, id_factura FROM facturi WHERE status = :v_citit' USING v_citit;
      LOOP
        FETCH c INTO v_data, v_status, v_id;
        EXIT WHEN c%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(v_id || ' ' || v_status || ' ' || TO_CHAR(v_data, 'YYYY-MM-DD'));
      END LOOP;
      CLOSE c;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('A apărut o eroare: ' || SQLERRM);
  END query_facturi;

  PROCEDURE update_products_price IS
    TYPE my_tab IS TABLE OF produse.id_produs%TYPE;
    tabel my_tab;

  BEGIN
    SELECT p.id_produs
    BULK COLLECT INTO tabel
    FROM produse p
    JOIN categorii c ON (p.id_categorie = c.id_categorie)
    WHERE LOWER(c.denumire) = 'it'; 

    FOR i IN tabel.FIRST .. tabel.LAST LOOP
      proc_ex2(tabel(i), -0.05);
    END LOOP;
  END update_products_price;

END curs_package;
/

