create PACKAGE pack_ex13
IS
--EX6
	 PROCEDURE afisare (nr_specializari OUT NUMBER, p_salariu IN angajat.salariu%TYPE);
--EX7
     PROCEDURE utilizator_comerciant (p_rating IN utilizator.rating_vanzator%TYPE);
--Ex8
    TYPE record_activitati IS RECORD (id_ang NUMBER(4),
                                      nume VARCHAR2(35),
                                     productivitate VARCHAR2(35));

    TYPE tablou_record_a IS TABLE OF record_activitati; 

    FUNCTION activitati (p_ora activitate.ora%TYPE default '09:00',p_stare activitate.stare_curenta%TYPE default 'in desfasurare')
    RETURN tablou_record_a;
--Ex9
    PROCEDURE nume_animal (p_data_infiintarii VARCHAR default '1986-01-01', v_rasa OUT animal.rasa%TYPE);
--Ex10-procedura pt a testa triggerul
    PROCEDURE operatii_comanda_utilizator (nr_maxim NUMBER DEFAULT 3); 
--ex12 - procedura pentru a vedea date despre trigger
    PROCEDURE date_trigger; 
END;
/

