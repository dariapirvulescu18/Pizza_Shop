create PACKAGE BODY pack_ex13
IS
--EX6
    PROCEDURE afisare (nr_specializari OUT NUMBER, p_salariu IN angajat.salariu%TYPE) IS
    
    --tablou indexat 
        TYPE tablou_indexat IS TABLE OF fermier%ROWTYPE INDEX BY BINARY_INTEGER;
    --tablou imbricat
        TYPE tablou_imbricat1 IS TABLE OF angajat.nume%TYPE;
        TYPE tablou_imbricat2 IS TABLE OF specializare.nume_s%TYPE;
    --vector
        TYPE vector IS VARRAY(15) OF angajat.salariu%TYPE;
    --extra:tip record 
        TYPE fermier_record IS RECORD (
            f_nume angajat.nume%TYPE,
            f_prenume angajat.prenume%TYPE,
            f_salariu angajat.salariu%TYPE
        );
        TYPE date_fermier IS VARRAY(100) OF fermier_record;
        date_fermier_var date_fermier:=date_fermier();
        t_ind tablou_indexat;
        t_imb tablou_imbricat1:= tablou_imbricat1();
        t_spc tablou_imbricat2;
        vec vector:= vector();

        v_salariu angajat.salariu%TYPE;
        v_nume angajat.nume%TYPE;
        v_nr NUMBER;
        v_nr_angajati NUMBER;
        v_nr_fermieri NUMBER;
        v_procent NUMBER;
        exceptia_mea EXCEPTION;
    BEGIN

    --obtinem angajatul si certificarea acestuia
        SELECT f.id_angajat,f.certificari
        BULK COLLECT INTO  t_ind
        FROM angajat a JOIN fermier f ON (f.id_angajat = a.id_angajat)
                JOIN urmeaza u ON (u.id_angajat = f.id_angajat)
                JOIN specializare s ON (s.id_specializare = u.id_specializare)
        WHERE a.salariu = ( SELECT min(salariu)
                            FROM angajat a2
                            JOIN fermier f2 ON (f2.id_angajat = a2.id_angajat)
                            JOIN urmeaza u2 ON (u2.id_angajat = f2.id_angajat)
                            JOIN specializare s2 ON (s2.id_specializare=u2.id_specializare)
                            WHERE s.id_specializare = s2.id_specializare)
         ORDER BY nume;
        --obtine salariu si nume 
        FOR i in t_ind.FIRST..t_ind.LAST LOOP
            SELECT nume, salariu
            INTO v_nume, v_salariu
            FROM angajat 
            WHERE id_angajat = t_ind(i).id_angajat;

            t_imb.extend;
            t_imb(i):= v_nume;
            vec.extend;
            vec(i):= v_salariu;
        END LOOP;

        --obtinem specializarea
        SELECT nume_s
        BULK COLLECT INTO  t_spc
        FROM angajat a JOIN fermier f ON (f.id_angajat = a.id_angajat)
                JOIN urmeaza u ON (u.id_angajat = f.id_angajat)
                JOIN specializare s ON (s.id_specializare = u.id_specializare)
        WHERE a.salariu = ( SELECT min(salariu)
                            FROM angajat a2
                            JOIN fermier f2 ON (f2.id_angajat = a2.id_angajat)
                            JOIN urmeaza u2 ON (u2.id_angajat = f2.id_angajat)
                            JOIN specializare s2 ON (s2.id_specializare=u2.id_specializare)
                            WHERE s.id_specializare = s2.id_specializare)
        ORDER BY nume;
        --vedem daca exista specializari fara angajati
        SELECT count(*)
        INTO v_nr
        FROM specializare;

        nr_specializari:=CARDINALITY(t_spc);

        --afisez datele obtinute 
        FOR i in t_ind.FIRST..t_ind.LAST LOOP
        DBMS_OUTPUT.PUT_LINE('Fermierul cu salariul cel mai mic din specializare: '||t_spc(i)||' este '||t_imb(i)||
        ',avand id-ul: '|| t_ind(i).id_angajat || ', salariul: ' ||vec(i)|| ' si are certificatul: '||t_ind(i).certificari);
        END LOOP;
        IF v_nr != nr_specializari THEN
            DBMS_OUTPUT.PUT_LINE ('Exista specializari in care nu lucreaza nimeni!');
        END IF; 

        --aflare procent

        IF p_salariu <=0 THEN
          RAISE exceptia_mea;
        END IF;

        SELECT count(id_angajat)
        INTO v_nr_angajati
        FROM angajat
        WHERE salariu > p_salariu;

        SELECT count(f.id_angajat)
        INTO v_nr_fermieri
        FROM fermier f join angajat a on (f.id_angajat=a.id_angajat)
        WHERE salariu > p_salariu;


        v_procent := round((v_nr_fermieri*100)/v_nr_angajati,4);
        DBMS_OUTPUT.PUT_LINE('Procentul de fermier cu salariu mai mare: '||v_procent||' %'); 
        SELECT nume, prenume, salariu
        BULK COLLECT INTO date_fermier_var
        FROM fermier f join angajat a on (f.id_angajat=a.id_angajat)
        WHERE salariu > p_salariu;
        --afisare
        FOR i in date_fermier_var.FIRST..date_fermier_var.LAST LOOP
        DBMS_OUTPUT.PUT_LINE('Fermierul: '||date_fermier_var(i).f_nume || ' '||date_fermier_var(i).f_prenume|| ' are salariul: '||date_fermier_var(i).f_salariu);
        END LOOP;

        EXCEPTION
        WHEN SUBSCRIPT_OUTSIDE_LIMIT THEN
         RAISE_APPLICATION_ERROR (-20144, 'Incercati sa aceesati nested_tabelul sau varray elementul la o pozitie inafara lui');
        WHEN COLLECTION_IS_NULL THEN
         RAISE_APPLICATION_ERROR (-20145, 'Nu ati initializat colectia de date');
         WHEN ZERO_DIVIDE THEN
         RAISE_APPLICATION_ERROR (-20146, 'Calcularea procentului va impartii la 0 produsul!');
          WHEN exceptia_mea THEN
         RAISE_APPLICATION_ERROR (-20147, 'Salariu nu poate fi un numar negativ sau 0');
         WHEN others THEN
         RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);

    END;
--EX7
    PROCEDURE utilizator_comerciant (p_rating IN utilizator.rating_vanzator%TYPE) IS
    TYPE refcursor IS REF CURSOR;
    CURSOR date_personale IS 
        SELECT id_user, prenume,
            CURSOR (SELECT nr_telefon, adresa
                    FROM comanda c
                    WHERE u.id_user = c.id_user)
        FROM utilizator u
        WHERE rating_vanzator = p_rating;
    CURSOR comm (v_id_user utilizator.id_user%TYPE)IS
            SELECT COUNT(c.id_comanda),COUNT(DISTINCT c.id_angajat)
            FROM comanda c JOIN angajat a ON c.id_angajat = a.id_angajat
            WHERE id_user = v_id_user
            GROUP BY id_user;

    v_cursor refcursor;
    d_id_user utilizator.id_user%TYPE;
    d_prenume_user utilizator.prenume%TYPE;
    ref_tel comanda.nr_telefon%TYPE;
    ref_adresa comanda.adresa%TYPE;

    c_nr_comenzi NUMBER;
    c_nr_angajati NUMBER;

    exceptia_mea EXCEPTION;

    BEGIN
        IF p_rating !='aur' AND p_rating !='argint' AND p_rating !='bronz' THEN
        RAISE exceptia_mea;
        END IF;
        OPEN date_personale;
        LOOP
            FETCH date_personale INTO d_id_user, d_prenume_user, v_cursor;
            EXIT WHEN  date_personale%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE('-------------------------------------');
            DBMS_OUTPUT.PUT_LINE ('Utilizatorul numit '||d_prenume_user || ' cu id-ul: ' || d_id_user || ' are:');
            DBMS_OUTPUT.PUT_LINE('-------------------------------------');
            OPEN comm(d_id_user);
            LOOP
                FETCH comm INTO c_nr_comenzi, c_nr_angajati;
                EXIT WHEN comm%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE('Nr comenzi: ' || c_nr_comenzi);
                DBMS_OUTPUT.PUT_LINE('Nr angajati care au lucrat la acele comenzi: ' || c_nr_angajati);
            END LOOP;
            IF comm%ROWCOUNT =0 THEN
                DBMS_OUTPUT.PUT_LINE('Utilizatorul nu a plasat nicio comanda');
                EXIT;
            END IF;
            CLOSE comm;
            DBMS_OUTPUT.PUT_LINE('Aceste comenzi s-au facut pe urmatoarele numere de telefon si la urmatoarele adrese: ');
            LOOP
                FETCH v_cursor INTO ref_tel, ref_adresa;
                EXIT WHEN v_cursor%NOTFOUND;
                DBMS_OUTPUT.PUT_LINE('Adresa: '||ref_adresa||' Nr telefon: '||ref_tel);
            END LOOP;
        END LOOP;
        CLOSE date_personale;
       EXCEPTION
        WHEN exceptia_mea THEN
         RAISE_APPLICATION_ERROR (-20145, 'Nu ati introdus date corecte de la tastatura!');
        WHEN others THEN
         RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
    END;
--EX8
    FUNCTION activitati (p_ora activitate.ora%TYPE default '09:00',p_stare activitate.stare_curenta%TYPE default 'in desfasurare')
    RETURN tablou_record_a IS tablou_act tablou_record_a;
    exceptie_ora EXCEPTION;
    exceptie_stare EXCEPTION;
    exceptie_null EXCEPTION;
    BEGIN
    IF NOT REGEXP_LIKE(p_ora, '^(0[0-9]|1[0-9]|2[0-4]):([0-5][0-9])$') THEN
        RAISE exceptie_ora;
    END IF;
    IF p_stare!='in desfasurare' AND p_stare!='anulata' AND  p_stare!='finalizata'THEN
        RAISE exceptie_stare;
    END IF;
    SELECT a.id_angajat, nume, productivitate
    BULK COLLECT INTO tablou_act
    FROM organizeaza o JOIN angajat a ON (o.id_angajat = a.id_angajat)
                       JOIN istoric i ON (i.id_angajat = a.id_angajat)
    WHERE id_activitate in (SELECT id_activitate
                            FROM ACTIVITATE
                            WHERE ora = p_ora AND stare_curenta = p_stare )
    GROUP BY a.id_angajat, nume, productivitate
    HAVING count(id_activitate)= (SELECT count(*)
                                FROM ACTIVITATE
                                WHERE ora = p_ora AND stare_curenta = p_stare);

    IF CARDINALITY(tablou_act)=0 THEN
    RAISE exceptie_null;
    END IF;
    RETURN tablou_act;
     EXCEPTION
        WHEN exceptie_ora THEN
         RAISE_APPLICATION_ERROR (-20146, 'Nu ati introdus prima valoare sub format de ora');
         RETURN NULL;
         WHEN exceptie_stare THEN
         RAISE_APPLICATION_ERROR (-20147, 'Nu ati introdus a doua valoare corect ');
         RETURN NULL;
         WHEN exceptie_null THEN
         RAISE_APPLICATION_ERROR (-20148, 'Nu s-au gasit angajati care sa indeplineasca criteriile cerute');
         RETURN NULL;
         WHEN others THEN
         RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
         RETURN NULL;
    END;
--EX9
    PROCEDURE nume_animal (p_data_infiintarii VARCHAR default '1986-01-01', v_rasa OUT animal.rasa%TYPE) IS 
         v_data DATE;
        exceptie_data EXCEPTION;
        exceptie_data_viitor EXCEPTION;

    BEGIN
        IF NOT REGEXP_LIKE(p_data_infiintarii, '^\d{4}-\d{2}-\d{2}$') THEN
            RAISE exceptie_data;
        END IF;

        v_data:=TO_DATE(p_data_infiintarii, 'YYYY-MM-DD');
        IF v_data >SYSDATE THEN
            RAISE exceptie_data_viitor;
        END IF;
        SELECT an.rasa
        INTO v_rasa
        FROM urmeaza u
            JOIN fermier f ON u.id_angajat = f.id_angajat
            JOIN specializare s ON u.id_specializare = s.id_specializare
            JOIN angajat a ON u.id_angajat = a.id_angajat
            JOIN ingrijeste i ON a.id_angajat = i.id_angajat
            JOIN animal an ON an.id_animal = i.id_animal
            WHERE (u.experienta_in_domeniu, u.id_specializare) IN (
                SELECT MAX(experienta_in_domeniu), id_specializare
                FROM urmeaza
                GROUP BY id_specializare
                HAVING COUNT(*) > 1
            )
            AND s.data_infiintarii > v_data;

        EXCEPTION
        WHEN NO_DATA_FOUND THEN
            RAISE_APPLICATION_ERROR(-20003,'Nu exista niciun fermier care sa respecte cerintele problemei sau nu exista niciun animal care sa fie ingrijit de acel fermier');
        WHEN TOO_MANY_ROWS THEN
            RAISE_APPLICATION_ERROR(-20004,'Exista mai multe animale ingrijite de acest fermier sau mai multi fermieri care respecta cerinta  ');
        WHEN exceptie_data THEN
            RAISE_APPLICATION_ERROR(-20005,'Ati introdus un format al datei incorect!');  
        WHEN exceptie_data_viitor THEN
            RAISE_APPLICATION_ERROR(-20006,'Ati introdus o data din viitor!');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM);

    END;

--ex10 procedura pentru a testa triggerul
    PROCEDURE operatii_comanda_utilizator (nr_maxim NUMBER DEFAULT 3) IS  
        TYPE tablou_indexat IS TABLE OF utilizator.id_user%TYPE INDEX BY BINARY_INTEGER;
        t_ind tablou_indexat;
        t_ind2 tablou_indexat;

        v_count NUMBER;
        v_random_index NUMBER;
        v_random_user_id NUMBER;
        exceptia_mea EXCEPTION;
    BEGIN
        IF nr_maxim<0 THEN
        RAISE exceptia_mea;
        END IF;
        WITH subq AS (
            SELECT id_user, COUNT(*) AS numar_comenzi
            FROM comanda
            GROUP BY id_user
            ORDER BY COUNT(*) DESC
        )
        SELECT u.id_user 
        BULK COLLECT INTO t_ind
        FROM utilizator u
        JOIN subq s ON u.id_user = s.id_user
        WHERE s.numar_comenzi = (SELECT max(numar_comenzi)
                                 FROM subq
                                 );
         --update                        
        FOR i in t_ind.FIRST..t_ind.LAST LOOP
            UPDATE utilizator
            SET rating_vanzator = 'aur'
            WHERE id_user=t_ind(i);

        END LOOP;
        DBMS_OUTPUT.PUT_LINE('UPDATE');
        v_count:= t_ind.COUNT;

        IF v_count >= nr_maxim THEN
            --insert
            INSERT INTO UTILIZATOR (id_user, nume, prenume,rating_vanzator)
            VALUES(SEQ_UTILIZATOR.NEXTVAL, 'Pirvulescu', 'Daria','bronz');
              DBMS_OUTPUT.PUT_LINE('INSERT');
        ELSE
            --delete
            SELECT id_user
            BULK COLLECT INTO t_ind2
            FROM comanda;
            DBMS_OUTPUT.PUT_LINE('DELETE');
            --alegem un utiliztaor random
            v_random_index := TRUNC(DBMS_RANDOM.VALUE * t_ind2.COUNT) + 1;
            v_random_user_id := t_ind2(v_random_index);
            --trebuie sters mai intai din comanda pentru a nu incalca constrangerea de cheie externa
            DELETE FROM comanda WHERE id_user= v_random_user_id;
            DELETE FROM utilizator WHERE id_user= v_random_user_id;

        END IF;
        EXCEPTION
        WHEN exceptia_mea THEN
            RAISE_APPLICATION_ERROR(-20009,'Ati introdus un numar negativ');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM); 
    END;
--ex12 -procedura pentru a afisa date despre trigger
    PROCEDURE date_trigger IS TYPE tip_c IS REF CURSOR;
    c_user tip_c;
    v_status USER_TRIGGERS.STATUS%TYPE;
    v_owner USER_TRIGGERS.TABLE_OWNER%TYPE;
    v_desc USER_TRIGGERS.DESCRIPTION%TYPE;
    BEGIN
        OPEN c_user FOR
            'SELECT STATUS,TABLE_OWNER,DESCRIPTION 
             FROM USER_TRIGGERS 
             WHERE lower(TRIGGER_NAME)=''ldd_trigger_procedure''';
        LOOP
            FETCH c_user INTO v_status,v_owner, v_desc;
            EXIT WHEN c_user%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('Utilizatorul '||v_owner||' are in schema triggerul ldd_trigger_procedure cu statusul: '||v_status||' descris ca:  '||v_desc);
        DBMS_OUTPUT.PUT_LINE('Pentru a nu se mai umple tabelul trigg_ldd_info se recomanda dezactivarea triggerului ldd_trigger_procedure');
        END LOOP;
    CLOSE c_user;
    END;
END;
/

