create PACKAGE pack_ex14
IS
    PROCEDURE statistici (p_tabel VARCHAR2 DEFAULT 'ANGAJAT');

    TYPE record_istoric IS RECORD(
                                    prod VARCHAR2(25),
                                    data_prom DATE,
                                    sal NUMBER(8),
                                    nume VARCHAR2(25),
                                    prenume VARCHAR2(25)
                                );

    TYPE table_of_record_istoric IS TABLE OF pack_ex14.record_istoric;
    FUNCTION info_istoric (p_productivitate istoric.productivitate%TYPE default 'crescuta') RETURN pack_ex14.table_of_record_istoric;
    PROCEDURE update_ang;

    TYPE tablou_imbricat_plante IS TABLE OF planta.denumire%TYPE;
    TYPE record_fermier IS RECORD(id_fermier NUMBER(4),
                                 tabel_planta tablou_imbricat_plante
                                    );
    TYPE tablou_imbricat_fermieri IS TABLE OF  record_fermier;   
    FUNCTION plante_f RETURN pack_ex14.tablou_imbricat_fermieri;
END;
/

