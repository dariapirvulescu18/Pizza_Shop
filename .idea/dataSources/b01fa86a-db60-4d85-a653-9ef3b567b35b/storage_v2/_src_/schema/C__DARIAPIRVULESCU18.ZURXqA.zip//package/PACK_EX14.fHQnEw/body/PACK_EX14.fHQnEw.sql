create PACKAGE BODY pack_ex14
IS
    
    PROCEDURE statistici (p_tabel VARCHAR2 DEFAULT 'ANGAJAT') IS 
       ex EXCEPTION;
       nr NUMBER;
       v_column_name    all_tab_columns.column_name%TYPE;
       v_num_distinct   all_tab_columns.num_distinct%TYPE;
       v_density        all_tab_columns.density%TYPE;
       v_most_analyzed  all_tab_columns.last_analyzed%TYPE;
       col SYS_REFCURSOR;
    BEGIN
       SELECT COUNT(*)
       INTO nr
       FROM user_tables
       WHERE table_name = UPPER(p_tabel); 

       IF nr = 0 THEN
          RAISE ex;
       END IF;

       DBMS_OUTPUT.PUT_LINE('Numele tabelului: ' || p_tabel);

       OPEN col FOR SELECT column_name, num_distinct, density, last_analyzed
                   FROM all_tab_columns
                   WHERE table_name = UPPER(p_tabel);
       LOOP
         FETCH col INTO  v_column_name,v_num_distinct,v_density,v_most_analyzed ;
         EXIT WHEN col%NOTFOUND;
         DBMS_OUTPUT.PUT_LINE('Coloana analizata: ' || v_column_name);
         DBMS_OUTPUT.PUT_LINE('Date distincte in coloana: ' || v_num_distinct);
         DBMS_OUTPUT.PUT_LINE('Densitate: ' || TO_CHAR(v_density, '0.99'));
         DBMS_OUTPUT.PUT_LINE('Cea mai frecventa analiza: ' || TO_CHAR(v_most_analyzed, 'YYYY-MM-DD HH24:MI:SS'));
         DBMS_OUTPUT.PUT_LINE('--------------------------------------');
       END LOOP;
    CLOSE col;
    EXCEPTION
       WHEN ex THEN
          RAISE_APPLICATION_ERROR(-20001, 'Nu exista acest tabel in schema.');
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM); 
    END statistici;
----------------------------------------------------------------------------------------------------
    FUNCTION info_istoric (p_productivitate istoric.productivitate%TYPE default 'crescuta')
    RETURN pack_ex14.table_of_record_istoric IS t_ist pack_ex14.table_of_record_istoric:=pack_ex14.table_of_record_istoric();
    ext EXCEPTION;
    BEGIN
        IF p_productivitate NOT IN( 'crescuta', 'scazuta') THEN
            RAISE ext;
        END IF;
        SELECT productivitate,data_promovarii,salariu,nume,prenume
        BULK COLLECT INTO t_ist
        FROM angajat a JOIN istoric i ON(a.id_angajat=i.id_angajat)
        WHERE productivitate=p_productivitate;
        RETURN t_ist;
       EXCEPTION
            WHEN ext THEN
                RAISE_APPLICATION_ERROR(-20009,'Ati introdus date gresite');
                RETURN NULL;
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM); 
                RETURN NULL;

    END info_istoric;
------------------------------------------------------------------------------   
    PROCEDURE update_ang IS
    TYPE tablou_imbricat IS TABLE OF angajat.id_angajat%TYPE;
    t_ind1 tablou_imbricat := tablou_imbricat();
    t_ind2 tablou_imbricat := tablou_imbricat();
    ok NUMBER(1);
    v_old_salary angajat.salariu%TYPE;
    v_new_salary angajat.salariu%TYPE;

BEGIN
    SELECT i.id_angajat
    BULK COLLECT INTO t_ind1
    FROM angajat a JOIN istoric i ON (a.id_angajat = i.id_angajat)
    WHERE productivitate = 'crescuta' AND data_promovarii IS NULL;

    SELECT i.id_angajat
    BULK COLLECT INTO t_ind2
    FROM angajat a JOIN istoric i ON (a.id_angajat = i.id_angajat)
    WHERE productivitate = 'crescuta' AND salariu < 5000;

    FOR i IN t_ind1.FIRST..t_ind1.LAST LOOP
        UPDATE istoric SET data_promovarii = SYSDATE WHERE id_angajat = t_ind1(i);
        DBMS_OUTPUT.PUT_LINE('UPDATE data_promovarii');
    END LOOP;

    FOR i IN t_ind2.FIRST..t_ind2.LAST LOOP
        ok := 1;
        FOR j IN t_ind1.FIRST..t_ind1.LAST LOOP
            IF t_ind1(j) = t_ind2(i) THEN
                ok := 0;
            END IF;
        END LOOP;
        IF ok = 1 THEN
            SELECT salariu INTO v_old_salary FROM angajat WHERE id_angajat = t_ind2(i);
            UPDATE angajat SET salariu = salariu * 1.1 WHERE id_angajat = t_ind2(i);
            SELECT salariu INTO v_new_salary FROM angajat WHERE id_angajat = t_ind2(i);
            DBMS_OUTPUT.PUT_LINE('UPDATE salariu pentru angajatul ' || t_ind2(i));
            DBMS_OUTPUT.PUT_LINE('Salariu vechi: ' || v_old_salary);
            DBMS_OUTPUT.PUT_LINE('Salariu nou: ' || v_new_salary);
        END IF;
    END LOOP;
END update_ang;
----------------------------------------------------------
     FUNCTION plante_f RETURN pack_ex14.tablou_imbricat_fermieri is 
     t_f pack_ex14.tablou_imbricat_fermieri:=pack_ex14.tablou_imbricat_fermieri(); 
     v_plante tablou_imbricat_plante:=tablou_imbricat_plante();
     v_record record_fermier;
     BEGIN
        FOR i in (SELECT id_angajat FROM fermier)LOOP
            v_plante.delete;
            v_record.id_fermier:=i.id_angajat;
            SELECT denumire
            BULK COLLECT INTO v_plante
            FROM fermier f join ingrijeste ii on (f.id_angajat=ii.id_angajat)
                            join planta p on (ii.id_planta=p.id_planta)
            WHERE ii.id_angajat=i.id_angajat;
            v_record.tabel_planta:=v_plante;
            t_f.extend;
            t_f(t_f.count) := v_record;
        END LOOP;
       RETURN t_f;
     END plante_f;
END pack_ex14;
/

