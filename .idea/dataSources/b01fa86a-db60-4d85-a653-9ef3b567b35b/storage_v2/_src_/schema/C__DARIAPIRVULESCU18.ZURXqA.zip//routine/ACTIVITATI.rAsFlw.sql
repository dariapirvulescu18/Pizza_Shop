create FUNCTION activitati (p_ora activitate.ora%TYPE default '09:00',p_stare activitate.stare_curenta%TYPE default 'in desfasurare')
    RETURN tablou_obiecte_a IS tablou_act tablou_obiecte_a:=tablou_obiecte_a();
    exceptie_ora EXCEPTION;
    exceptie_stare EXCEPTION;
    exceptie_null EXCEPTION;
BEGIN
IF NOT REGEXP_LIKE(p_ora, '^(0[0-9]|1[0-9]|2[0-4]):([0-5][0-9])$') THEN
    RAISE exceptie_ora;
END IF;
IF p_stare!='in desfasurare' AND p_stare!='anulata' AND  p_stare!='finalizata'THEN
    RAISE exceptie_stare;
END IF;
SELECT obiect_activitati(a.id_angajat, nume, productivitate)
BULK COLLECT INTO tablou_act
FROM organizeaza o JOIN angajat a ON (o.id_angajat = a.id_angajat)
                   JOIN istoric i ON (i.id_angajat = a.id_angajat)
WHERE id_activitate in (SELECT id_activitate
                        FROM ACTIVITATE
                        WHERE ora = p_ora AND stare_curenta = p_stare )
GROUP BY a.id_angajat, nume, productivitate
HAVING count(id_activitate)= (SELECT count(*)
                            FROM ACTIVITATE
                            WHERE ora = p_ora AND stare_curenta = p_stare);

IF CARDINALITY(tablou_act)=0 THEN
RAISE exceptie_null;
END IF;
RETURN tablou_act;
 EXCEPTION
    WHEN exceptie_ora THEN
     RAISE_APPLICATION_ERROR (-20146, 'Nu ati introdus prima valoare sub format de ora');
     RETURN NULL;
     WHEN exceptie_stare THEN
     RAISE_APPLICATION_ERROR (-20147, 'Nu ati introdus a doua valoare corect ');
     RETURN NULL;
     WHEN exceptie_null THEN
     RAISE_APPLICATION_ERROR (-20148, 'Nu s-au gasit angajati care sa indeplineasca criteriile cerute');
     RETURN NULL;
     WHEN others THEN
     RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
     RETURN NULL;
END;
/

