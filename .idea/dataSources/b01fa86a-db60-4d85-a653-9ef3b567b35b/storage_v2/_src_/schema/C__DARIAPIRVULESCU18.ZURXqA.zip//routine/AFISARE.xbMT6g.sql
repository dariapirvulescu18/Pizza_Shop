create PROCEDURE afisare (nr_specializari OUT NUMBER, p_salariu IN angajat.salariu%TYPE) IS

--tablou indexat 
    TYPE tablou_indexat IS TABLE OF fermier%ROWTYPE INDEX BY BINARY_INTEGER;
--tablou imbricat
    TYPE tablou_imbricat1 IS TABLE OF angajat.nume%TYPE;
    TYPE tablou_imbricat2 IS TABLE OF specializare.nume_s%TYPE;
--vector
    TYPE vector IS VARRAY(15) OF angajat.salariu%TYPE;
--extra:tip record 
    TYPE fermier_record IS RECORD (
        f_nume angajat.nume%TYPE,
        f_prenume angajat.prenume%TYPE,
        f_salariu angajat.salariu%TYPE
    );
    TYPE date_fermier IS VARRAY(100) OF fermier_record;
    date_fermier_var date_fermier:=date_fermier();
    t_ind tablou_indexat;
    t_imb tablou_imbricat1:= tablou_imbricat1();
    t_spc tablou_imbricat2;
    vec vector:= vector();

    v_salariu angajat.salariu%TYPE;
    v_nume angajat.nume%TYPE;
    v_nr NUMBER;
    v_nr_angajati NUMBER;
    v_nr_fermieri NUMBER;
    v_procent NUMBER;
    exceptia_mea EXCEPTION;
BEGIN

--obtinem angajatul si certificarea acestuia
    SELECT f.id_angajat,f.certificari
    BULK COLLECT INTO  t_ind
    FROM angajat a JOIN fermier f ON (f.id_angajat = a.id_angajat)
            JOIN urmeaza u ON (u.id_angajat = f.id_angajat)
            JOIN specializare s ON (s.id_specializare = u.id_specializare)
    WHERE a.salariu = ( SELECT min(salariu)
                        FROM angajat a2
                        JOIN fermier f2 ON (f2.id_angajat = a2.id_angajat)
                        JOIN urmeaza u2 ON (u2.id_angajat = f2.id_angajat)
                        JOIN specializare s2 ON (s2.id_specializare=u2.id_specializare)
                        WHERE s.id_specializare = s2.id_specializare)
     ORDER BY nume;
    --obtine salariu si nume 
    FOR i in t_ind.FIRST..t_ind.LAST LOOP
        SELECT nume, salariu
        INTO v_nume, v_salariu
        FROM angajat 
        WHERE id_angajat = t_ind(i).id_angajat;

        t_imb.extend;
        t_imb(i):= v_nume;
        vec.extend;
        vec(i):= v_salariu;
    END LOOP;

    --obtinem specializarea
    SELECT nume_s
    BULK COLLECT INTO  t_spc
    FROM angajat a JOIN fermier f ON (f.id_angajat = a.id_angajat)
            JOIN urmeaza u ON (u.id_angajat = f.id_angajat)
            JOIN specializare s ON (s.id_specializare = u.id_specializare)
    WHERE a.salariu = ( SELECT min(salariu)
                        FROM angajat a2
                        JOIN fermier f2 ON (f2.id_angajat = a2.id_angajat)
                        JOIN urmeaza u2 ON (u2.id_angajat = f2.id_angajat)
                        JOIN specializare s2 ON (s2.id_specializare=u2.id_specializare)
                        WHERE s.id_specializare = s2.id_specializare)
    ORDER BY nume;
    --vedem daca exista specializari fara angajati
    SELECT count(*)
    INTO v_nr
    FROM specializare;

    nr_specializari:=CARDINALITY(t_spc);

    --afisez datele obtinute 
    FOR i in t_ind.FIRST..t_ind.LAST LOOP
    DBMS_OUTPUT.PUT_LINE('Fermierul cu salariul cel mai mic din specializare: '||t_spc(i)||' este '||t_imb(i)||
    ',avand id-ul: '|| t_ind(i).id_angajat || ', salariul: ' ||vec(i)|| ' si are certificatul: '||t_ind(i).certificari);
    END LOOP;
    IF v_nr != nr_specializari THEN
        DBMS_OUTPUT.PUT_LINE ('Exista specializari in care nu lucreaza nimeni!');
    END IF; 

    --aflare procent

    IF p_salariu <=0 THEN
      RAISE exceptia_mea;
    END IF;

    SELECT count(id_angajat)
    INTO v_nr_angajati
    FROM angajat
    WHERE salariu > p_salariu;

    SELECT count(f.id_angajat)
    INTO v_nr_fermieri
    FROM fermier f join angajat a on (f.id_angajat=a.id_angajat)
    WHERE salariu > p_salariu;


    v_procent := round((v_nr_fermieri*100)/v_nr_angajati,4);
    DBMS_OUTPUT.PUT_LINE('Procentul de fermier cu salariu mai mare: '||v_procent||' %'); 
    SELECT nume, prenume, salariu
    BULK COLLECT INTO date_fermier_var
    FROM fermier f join angajat a on (f.id_angajat=a.id_angajat)
    WHERE salariu > p_salariu;
    --afisare
    FOR i in date_fermier_var.FIRST..date_fermier_var.LAST LOOP
    DBMS_OUTPUT.PUT_LINE('Fermierul: '||date_fermier_var(i).f_nume || ' '||date_fermier_var(i).f_prenume|| ' are salariul: '||date_fermier_var(i).f_salariu);
    END LOOP;

    EXCEPTION
    WHEN SUBSCRIPT_OUTSIDE_LIMIT THEN
     RAISE_APPLICATION_ERROR (-20144, 'Incercati sa aceesati nested_tabelul sau varray elementul la o pozitie inafara lui');
    WHEN COLLECTION_IS_NULL THEN
     RAISE_APPLICATION_ERROR (-20145, 'Nu ati initializat colectia de date');
     WHEN ZERO_DIVIDE THEN
     RAISE_APPLICATION_ERROR (-20146, 'Calcularea procentului va impartii la 0 produsul!');
      WHEN exceptia_mea THEN
     RAISE_APPLICATION_ERROR (-20147, 'Salariu nu poate fi un numar negativ sau 0');
     WHEN others THEN
     RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);

END;
/

