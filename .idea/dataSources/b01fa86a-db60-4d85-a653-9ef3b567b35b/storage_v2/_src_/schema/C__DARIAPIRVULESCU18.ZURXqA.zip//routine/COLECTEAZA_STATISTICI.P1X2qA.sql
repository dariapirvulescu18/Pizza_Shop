create PROCEDURE colecteaza_statistici
	(p_obiect_tip IN VARCHAR2, p_obiect_nume IN VARCHAR2)
IS
BEGIN
	DBMS_DDL.ANALYZE_OBJECT(p_obiect_tip,USER,UPPER(p_obiect_nume),'COMPUTE');
END;
/

