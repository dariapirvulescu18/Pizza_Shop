create FUNCTION data_n (v_nume angajat.nume%TYPE DEFAULT 'Ionescu')
RETURN DATE IS
  data angajat.data_nastere%type;
BEGIN
  SELECT data_nastere INTO data
  FROM angajat
  WHERE nume = v_nume;

  RETURN data;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    RAISE_APPLICATION_ERROR(-20000, 'Nu exista angajati cu numele dat');
  WHEN TOO_MANY_ROWS THEN
    RAISE_APPLICATION_ERROR(-20001, 'Exista mai multi angajati cu numele dat');
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(-20002, 'Alta eroare!');
END data_n;
/

