create PROCEDURE date_angajat ( v_result pack_ex14.table_of_record_istoric)
authid current_user
as
inserari VARCHAR(300);
BEGIN
    FOR t IN (SELECT table_name FROM user_tables WHERE table_name = 'ANGAJAT_NOU') LOOP
        EXECUTE IMMEDIATE 'DROP TABLE angajat_nou';
    END LOOP;
    EXECUTE IMMEDIATE
        'CREATE TABLE angajat_nou ( id_ang_nou NUMBER(5),
                                    prod VARCHAR2(25),
                                    data_prom DATE,
                                    sal NUMBER(8),
                                    nume_complet full_name)';
    FOR i IN 1..v_result.COUNT LOOP
        inserari:='INSERT INTO angajat_nou VALUES(i,v_result(i).prod,NVL(TO_CHAR(v_result(i).data_prom, ''YYYY-MM-DD''),''Angajatul nu a fost niciodata promovat''),
        v_result(i).sal,full_name(v_result(i).nume,v_result(i).prenume))';
        EXECUTE IMMEDIATE inserari;
    END LOOP;
    EXECUTE IMMEDIATE 'SELECT * FROM angajat_nou';
    EXECUTE IMMEDIATE 'DROP TABLE angajat_nou';
END;
/

