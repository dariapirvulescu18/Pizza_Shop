create PROCEDURE dezactivare IS TYPE tip_c IS REF CURSOR;
c_user tip_c;
v_status USER_TRIGGERS.STATUS%TYPE;
v_owner USER_TRIGGERS.TABLE_OWNER%TYPE;
v_desc USER_TRIGGERS.DESCRIPTION%TYPE;
BEGIN
    OPEN c_user FOR
        'SELECT STATUS,TABLE_OWNER,DESCRIPTION 
         FROM USER_TRIGGERS 
         WHERE lower(TRIGGER_NAME)=''ldd_trigger_procedure''';
    LOOP
        FETCH c_user INTO v_status,v_owner, v_desc;
		EXIT WHEN c_user%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE('Utilizatorul '||v_owner||' are in schema triggerul ldd_trigger_procedure cu statusul: '||v_status||' descris ca:  '||v_desc);
	DBMS_OUTPUT.PUT_LINE('Pentru a nu se mai umple tabelul trigg_ldd_info se recomanda dezactivarea truggerului ldd_trigger_procedure');
    END LOOP;
CLOSE c_user;
END;
/

