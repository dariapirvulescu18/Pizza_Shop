create FUNCTION experienta (p_data_infiintarii specializare.data_infiintarii%TYPE default '1986-01-01')
    RETURN tablou_animale IS t_nume tablou_animale:=tablou_animale();
BEGIN
    SELECT an.rasa
    BULK COLLECT INTO  t_nume
    FROM urmeaza u
    JOIN fermier f ON u.id_angajat = f.id_angajat
    JOIN specializare s ON u.id_specializare = s.id_specializare
    JOIN angajat a ON u.id_angajat = a.id_angajat
    JOIN ingrijeste i ON a.id_angajat = i.id_angajat
    JOIN animal an ON an.id_animal = i.id_animal
    WHERE (u.experienta_in_domeniu, u.id_specializare) IN (
        SELECT MAX(experienta_in_domeniu), id_specializare
        FROM urmeaza
        GROUP BY id_specializare
        HAVING COUNT(*) > 1
    )
    AND s.data_infiintarii > TO_DATE(p_data_infiintarii, 'YYYY-MM-DD');
END;
/

