create PROCEDURE gather_statistics_for_angajat IS
BEGIN
  -- Gather statistics for the angajat table, including histograms for all columns.
  DBMS_STATS.GATHER_TABLE_STATS(
    ownname      => 'C#DARIAPIRVULESCU',  -- Replace with your schema name
    tabname      => 'angajat',      -- Replace with your table name
    cascade      => TRUE,
    method_opt   => 'FOR ALL COLUMNS SIZE AUTO',
    degree       => DBMS_STATS.AUTO_DEGREE,
    granularity  => 'ALL',
    estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE
  );

  -- You can add additional statements or actions if needed.

  DBMS_OUTPUT.PUT_LINE('Statistics for table angajat collected successfully.');
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END gather_statistics_for_angajat;
/

