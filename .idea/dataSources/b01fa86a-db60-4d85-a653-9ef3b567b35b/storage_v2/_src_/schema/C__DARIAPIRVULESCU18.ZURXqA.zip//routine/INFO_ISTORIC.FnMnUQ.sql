create FUNCTION info_istoric (p_productivitate istoric.productivitate%TYPE default 'crescuta')
RETURN table_of_record_istoric IS t_ist table_of_record_istoric;
ext EXCEPTION;
BEGIN
    IF p_productivitate NOT IN( 'crescuta', 'scazuta') THEN
        RAISE ext;
    END IF;
    SELECT record_istoric(productivitate,data_promovarii,salariu,nume,prenume)
    BULK COLLECT INTO t_ist
    FROM angajat a JOIN istoric i ON(a.id_angajat=i.id_angajat)
    WHERE productivitate=p_productivitate;
    RETURN t_ist;
   EXCEPTION
        WHEN ext THEN
            RAISE_APPLICATION_ERROR(-20009,'Ati introdus date gresite');
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM); 

END;
/

