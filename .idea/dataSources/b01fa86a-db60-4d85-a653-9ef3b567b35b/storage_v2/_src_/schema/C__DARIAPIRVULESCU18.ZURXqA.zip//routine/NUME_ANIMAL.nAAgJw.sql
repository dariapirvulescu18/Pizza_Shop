create PROCEDURE nume_animal (p_data_infiintarii VARCHAR default '1986-01-01', v_rasa OUT animal.rasa%TYPE) IS 
     v_data DATE;
    exceptie_data EXCEPTION;
    exceptie_data_viitor EXCEPTION;

BEGIN
    IF NOT REGEXP_LIKE(p_data_infiintarii, '^\d{4}-\d{2}-\d{2}$') THEN
        RAISE exceptie_data;
    END IF;

    v_data:=TO_DATE(p_data_infiintarii, 'YYYY-MM-DD');
    IF v_data >SYSDATE THEN
        RAISE exceptie_data_viitor;
    END IF;
    SELECT an.rasa
    INTO v_rasa
    FROM urmeaza u
        JOIN fermier f ON u.id_angajat = f.id_angajat
        JOIN specializare s ON u.id_specializare = s.id_specializare
        JOIN angajat a ON u.id_angajat = a.id_angajat
        JOIN ingrijeste i ON a.id_angajat = i.id_angajat
        JOIN animal an ON an.id_animal = i.id_animal
        WHERE (u.experienta_in_domeniu, u.id_specializare) IN (
            SELECT MAX(experienta_in_domeniu), id_specializare
            FROM urmeaza
            GROUP BY id_specializare
            HAVING COUNT(*) > 1
        )
        AND s.data_infiintarii > v_data;

    EXCEPTION
	WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003,'Nu exista niciun fermier care sa respecte cerintele problemei sau nu exista niciun animal care sa fie ingrijit de acel fermier');
	WHEN TOO_MANY_ROWS THEN
		RAISE_APPLICATION_ERROR(-20004,'Exista mai multe animale ingrijite de acest fermier sau mai multi fermieri care respecta cerinta  ');
    WHEN exceptie_data THEN
        RAISE_APPLICATION_ERROR(-20005,'Ati introdus un format al datei incorect!');  
    WHEN exceptie_data_viitor THEN
        RAISE_APPLICATION_ERROR(-20006,'Ati introdus o data din viitor!');
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM);

END;
/

