create PROCEDURE operatii_comanda_utilizator (nr_maxim NUMBER DEFAULT 3) IS  
    TYPE tablou_indexat IS TABLE OF utilizator.id_user%TYPE INDEX BY BINARY_INTEGER;
    t_ind tablou_indexat;
    t_ind2 tablou_indexat;

    v_count NUMBER;
    v_random_index NUMBER;
    v_random_user_id NUMBER;
    exceptia_mea EXCEPTION;
BEGIN
    IF nr_maxim<0 THEN
    RAISE exceptia_mea;
    END IF;
    WITH subq AS (
        SELECT id_user, COUNT(*) AS numar_comenzi
        FROM comanda
        GROUP BY id_user
        ORDER BY COUNT(*) DESC
    )
    SELECT u.id_user 
    BULK COLLECT INTO t_ind
    FROM utilizator u
    JOIN subq s ON u.id_user = s.id_user
    WHERE s.numar_comenzi = (SELECT max(numar_comenzi)
                             FROM subq
                             );
     --update                        
    FOR i in t_ind.FIRST..t_ind.LAST LOOP
        UPDATE utilizator
        SET rating_vanzator = 'aur'
        WHERE id_user=t_ind(i);
         DBMS_OUTPUT.PUT_LINE('UPDATE');
    END LOOP;

    v_count:= t_ind.COUNT;

    IF v_count >= nr_maxim THEN
        --insert
        INSERT INTO UTILIZATOR (id_user, nume, prenume,rating_vanzator)
        VALUES(SEQ_UTILIZATOR.NEXTVAL, 'Pirvulescu', 'Daria','bronz');
         DBMS_OUTPUT.PUT_LINE('INSERT');
    ELSE
        --delete
        SELECT id_user
        BULK COLLECT INTO t_ind2
        FROM comanda;
         DBMS_OUTPUT.PUT_LINE('DELETE');
        --alegem un utiliztaor random
        v_random_index := TRUNC(DBMS_RANDOM.VALUE * t_ind2.COUNT) + 1;
        v_random_user_id := t_ind2(v_random_index);
        --trebuie sters mai intai din comanda pentru a nu incalca constrangerea de cheie externa
        DELETE FROM comanda WHERE id_user= v_random_user_id;
        DELETE FROM utilizator WHERE id_user= v_random_user_id;

    END IF;
    EXCEPTION
    WHEN exceptia_mea THEN
        RAISE_APPLICATION_ERROR(-20009,'Ati introdus un numar negativ');
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM); 
END;
/

