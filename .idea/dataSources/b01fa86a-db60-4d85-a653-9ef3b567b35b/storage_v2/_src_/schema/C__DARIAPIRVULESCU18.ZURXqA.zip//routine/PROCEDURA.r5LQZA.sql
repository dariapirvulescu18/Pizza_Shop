create PROCEDURE procedura(cursor_din OUT SYS_REFCURSOR)IS 
BEGIN
    OPEN cursor_din FOR 'SELECT id_angajat
                         FROM angajat
                         WHERE salariu>1000';  
END;
/

