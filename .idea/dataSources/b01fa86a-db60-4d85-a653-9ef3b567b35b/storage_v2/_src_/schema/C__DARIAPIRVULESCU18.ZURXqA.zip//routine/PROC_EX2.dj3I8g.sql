create PROCEDURE proc_ex2
	(v_id IN produse.id_produs%TYPE, v_procent NUMBER)
AS
	exceptie EXCEPTION;
BEGIN
	UPDATE produse
	SET pret_unitar= pret_unitar*(1+v_procent)
	WHERE id_produs=v_id;
	IF SQL%NOTFOUND THEN
		RAISE exceptie;
	END IF;
	EXCEPTION
		WHEN exceptie THEN
			RAISE_APPLICATION_ERROR(-20000,'Nu exista produsul');
END;
/

