create PROCEDURE scriu_fisier_dpi
(director VARCHAR2,fisier VARCHAR2) IS
v_file UTL_FILE.FILE_TYPE;
CURSOR cursor_rez IS
SELECT nationalitate nat, SUM(salariu) suma
FROM angajat
GROUP BY nationalitate
ORDER BY SUM(salariu);
v_rez cursor_rez%ROWTYPE;
BEGIN
v_file:=UTL_FILE.FOPEN(director, fisier, 'w');
UTL_FILE.PUTF(v_file, 'Suma salariilor pe nationalitae \n Raport generat pe data ');
UTL_FILE.PUT(v_file, SYSDATE);
UTL_FILE.NEW_LINE(v_file);
OPEN cursor_rez;
LOOP
FETCH cursor_rez INTO v_rez;
EXIT WHEN cursor_rez%NOTFOUND;
UTL_FILE.NEW_LINE(v_file);
UTL_FILE.PUT(v_file, v_rez.nat);
UTL_FILE.PUT(v_file, ' ');
UTL_FILE.PUT(v_file, v_rez.suma);
END LOOP;
CLOSE cursor_rez;
UTL_FILE.FCLOSE(v_file);
END;
/

