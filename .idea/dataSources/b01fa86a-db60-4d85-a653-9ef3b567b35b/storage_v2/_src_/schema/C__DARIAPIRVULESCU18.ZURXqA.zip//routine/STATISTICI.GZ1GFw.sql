create PROCEDURE statistici (p_tabel VARCHAR2 DEFAULT 'ANGAJAT') IS 
   ex EXCEPTION;
   nr NUMBER;
   v_column_name    all_tab_columns.column_name%TYPE;
   v_num_distinct   all_tab_columns.num_distinct%TYPE;
   v_density        all_tab_columns.density%TYPE;
   v_most_analyzed  all_tab_columns.last_analyzed%TYPE;
BEGIN
   SELECT COUNT(*)
   INTO nr
   FROM user_tables
   WHERE table_name = UPPER(p_tabel); 

   IF nr = 0 THEN
      RAISE ex;
   END IF;

   DBMS_OUTPUT.PUT_LINE('Numele tabelului: ' || p_tabel);
   FOR col IN (SELECT column_name, num_distinct, density, last_analyzed
               FROM all_tab_columns
               WHERE table_name = UPPER(p_tabel))
   LOOP
     v_column_name    := col.column_name;
     v_num_distinct   := col.num_distinct;
     v_density        := col.density;
     v_most_analyzed  := col.last_analyzed;
     DBMS_OUTPUT.PUT_LINE('Coloana analizata: ' || v_column_name);
     DBMS_OUTPUT.PUT_LINE('Date distincte in coloana: ' || v_num_distinct);
     DBMS_OUTPUT.PUT_LINE('Densitate: ' || TO_CHAR(v_density, '0.99'));
     DBMS_OUTPUT.PUT_LINE('Cea mai frecventa analiza: ' || TO_CHAR(v_most_analyzed, 'YYYY-MM-DD HH24:MI:SS'));
     DBMS_OUTPUT.PUT_LINE('--------------------------------------');
   END LOOP;

EXCEPTION
   WHEN ex THEN
      RAISE_APPLICATION_ERROR(-20001, 'Nu exista acest tabel in schema.');
END;
/

