create PROCEDURE update_ang IS
    TYPE tablou_imbricat IS TABLE OF angajat.id_angajat%TYPE;
    t_ind1 tablou_imbricat := tablou_imbricat();
    t_ind2 tablou_imbricat := tablou_imbricat();
    ok NUMBER(1);
    v_old_salary angajat.salariu%TYPE;
    v_new_salary angajat.salariu%TYPE;

BEGIN
    SELECT i.id_angajat
    BULK COLLECT INTO t_ind1
    FROM angajat a JOIN istoric i ON (a.id_angajat = i.id_angajat)
    WHERE productivitate = 'crescuta' AND data_promovarii IS NULL;

    SELECT i.id_angajat
    BULK COLLECT INTO t_ind2
    FROM angajat a JOIN istoric i ON (a.id_angajat = i.id_angajat)
    WHERE productivitate = 'crescuta' AND salariu < 5000;

    FOR i IN t_ind1.FIRST..t_ind1.LAST LOOP
        UPDATE istoric SET data_promovarii = SYSDATE WHERE id_angajat = t_ind1(i);
        DBMS_OUTPUT.PUT_LINE('UPDATE data_promovarii');
    END LOOP;

    FOR i IN t_ind2.FIRST..t_ind2.LAST LOOP
        ok := 1;
        FOR j IN t_ind1.FIRST..t_ind1.LAST LOOP
            IF t_ind1(j) = t_ind2(i) THEN
                ok := 0;
            END IF;
        END LOOP;
        IF ok = 1 THEN
            SELECT salariu INTO v_old_salary FROM angajat WHERE id_angajat = t_ind2(i);
            UPDATE angajat SET salariu = salariu * 1.1 WHERE id_angajat = t_ind2(i);
            SELECT salariu INTO v_new_salary FROM angajat WHERE id_angajat = t_ind2(i);
            DBMS_OUTPUT.PUT_LINE('UPDATE salariu pentru angajatul ' || t_ind2(i));
            DBMS_OUTPUT.PUT_LINE('Salariu vechi: ' || v_old_salary);
            DBMS_OUTPUT.PUT_LINE('Salariu nou: ' || v_new_salary);
        END IF;
    END LOOP;
END;
/

