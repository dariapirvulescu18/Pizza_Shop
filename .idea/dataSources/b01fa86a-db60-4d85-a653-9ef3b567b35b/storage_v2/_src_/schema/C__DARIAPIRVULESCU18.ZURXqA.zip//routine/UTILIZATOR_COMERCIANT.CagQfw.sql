create PROCEDURE utilizator_comerciant (p_rating IN utilizator.rating_vanzator%TYPE) IS
TYPE refcursor IS REF CURSOR;
CURSOR date_personale IS 
    SELECT id_user, prenume,
        CURSOR (SELECT nr_telefon, adresa
                FROM comanda c
                WHERE u.id_user = c.id_user)
    FROM utilizator u
    WHERE rating_vanzator = p_rating;
CURSOR comm (v_id_user utilizator.id_user%TYPE)IS
        SELECT COUNT(c.id_comanda),COUNT(DISTINCT c.id_angajat)
        FROM comanda c JOIN angajat a ON c.id_angajat = a.id_angajat
        WHERE id_user = v_id_user
        GROUP BY id_user;

v_cursor refcursor;
d_id_user utilizator.id_user%TYPE;
d_prenume_user utilizator.prenume%TYPE;
ref_tel comanda.nr_telefon%TYPE;
ref_adresa comanda.adresa%TYPE;

c_nr_comenzi NUMBER;
c_nr_angajati NUMBER;

exceptia_mea EXCEPTION;

BEGIN
    IF p_rating !='aur' AND p_rating !='argint' AND p_rating !='bronz' THEN
    RAISE exceptia_mea;
    END IF;
    OPEN date_personale;
    LOOP
        FETCH date_personale INTO d_id_user, d_prenume_user, v_cursor;
        EXIT WHEN  date_personale%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE('-------------------------------------');
        DBMS_OUTPUT.PUT_LINE ('Utilizatorul numit '||d_prenume_user || ' cu id-ul: ' || d_id_user || ' are:');
        DBMS_OUTPUT.PUT_LINE('-------------------------------------');
        OPEN comm(d_id_user);
        LOOP
            FETCH comm INTO c_nr_comenzi, c_nr_angajati;
            EXIT WHEN comm%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE('Nr comenzi: ' || c_nr_comenzi);
            DBMS_OUTPUT.PUT_LINE('Nr angajati care au lucrat la acele comenzi: ' || c_nr_angajati);
        END LOOP;
        IF comm%ROWCOUNT =0 THEN
            DBMS_OUTPUT.PUT_LINE('Utilizatorul nu a plasat nicio comanda');
            EXIT;
        END IF;
        CLOSE comm;
        DBMS_OUTPUT.PUT_LINE('Aceste comenzi s-au facut pe urmatoarele numere de telefon si la urmatoarele adrese: ');
        LOOP
            FETCH v_cursor INTO ref_tel, ref_adresa;
            EXIT WHEN v_cursor%NOTFOUND;
            DBMS_OUTPUT.PUT_LINE('Adresa: '||ref_adresa||' Nr telefon: '||ref_tel);
        END LOOP;
    END LOOP;
    CLOSE date_personale;
   EXCEPTION
    WHEN exceptia_mea THEN
     RAISE_APPLICATION_ERROR (-20145, 'Nu ati introdus date corecte de la tastatura!');
    WHEN others THEN
     RAISE_APPLICATION_ERROR (SQLCODE, SQLERRM);
END;
/

