create trigger TRIG_EX11_CORECT
    instead of insert or update of ID_SOFER
    on CAMION_DE_MARFA
    for each row
    COMPOUND TRIGGER
TYPE sofer IS RECORD(id_sofer NUMBER(4),
                   nr_camioane NUMBER(4));
TYPE tablou_indexat1 IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
TYPE tablou_indexat2 IS TABLE OF sofer INDEX BY PLS_INTEGER;
        t_ind2 tablou_indexat2;
        t_ind1 tablou_indexat1;
        contor NUMBER(4) := 0;
        ok BOOLEAN:=FALSE;
BEFORE STATEMENT IS
    BEGIN
        contor := 0;
        SELECT id_sofer, COUNT(*)
        BULK COLLECT INTO t_ind2
        FROM camion_de_marfa 
        GROUP BY id_sofer;
END BEFORE STATEMENT;
BEFORE EACH ROW IS 
    BEGIN
        FOR i in 1..t_ind2.LAST LOOP
            IF  t_ind2(i).id_sofer = :NEW.id_sofer AND t_ind2(i).nr_camioane + contor >= 1 THEN
                RAISE_APPLICATION_ERROR(-20001, 'Incercati sa atribuiti unui sofer mai mult de 1 camion');
            END IF;
        END LOOP;
        contor := contor + 1;

        SELECT id_sofer
        BULK COLLECT INTO t_ind1
        FROM sofer;

        FOR i in t_ind1.FIRST..t_ind1.LAST LOOP
            IF t_ind1(i)= :NEW.id_sofer THEN
                ok:=TRUE;
                EXIT;
            END IF;
        END LOOP;
        IF ok=FALSE THEN

            RAISE_APPLICATION_ERROR(-20001, 'Incercati sa atribuiti unui angajat care nu este sofer un camion de marfa');
        END IF;
    END BEFORE EACH ROW;
END trig_ex11_corect;
/

