create trigger TRIG_EX11_MUTATING
    before insert or update of ID_SOFER
    on CAMION_DE_MARFA
    for each row
DECLARE
    v_nr_camioane NUMBER := 0;
    TYPE tablou_indexat IS TABLE OF sofer.id_sofer%TYPE INDEX BY BINARY_INTEGER;
    t_ind tablou_indexat;
    ok BOOLEAN:=FALSE;
BEGIN
    SELECT COUNT(*)
    INTO v_nr_camioane
    FROM camion_de_marfa 
    WHERE id_sofer = :NEW.id_sofer;

    SELECT id_sofer
    BULK COLLECT INTO t_ind
    FROM sofer;

    FOR i in t_ind.FIRST..t_ind.LAST LOOP
        IF t_ind(i)= :NEW.id_sofer THEN
            ok:=TRUE;
            EXIT;
        END IF;
    END LOOP;
    IF ok=FALSE THEN
        RAISE_APPLICATION_ERROR(-20001, 'Incercati sa atribuiti unui angajat care nu este sofer un camion de marfa');
    END IF;

    IF v_nr_camioane >= 1 THEN
        RAISE_APPLICATION_ERROR(-20002, 'Incercati sa atribuiti unui sofer mai mult de 1 camion');
    END IF;

END;
/

