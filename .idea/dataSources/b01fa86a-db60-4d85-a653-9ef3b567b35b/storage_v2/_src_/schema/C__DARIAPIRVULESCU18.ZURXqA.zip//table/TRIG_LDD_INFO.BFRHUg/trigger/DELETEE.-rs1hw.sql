create trigger DELETEE
    before insert
    on TRIG_LDD_INFO
DECLARE
 v_record_count NUMBER;
 BEGIN
  SELECT COUNT(*) INTO v_record_count FROM trig_ldd_info;
    IF v_record_count >= 10 THEN
        DELETE  from trig_ldd_info;
        DBMS_OUTPUT.PUT_LINE('S-au sters datele din tabelul trig_ldd_info');
        --se va apela o procedura pentru a dezactiva triggerul de tip LDD
        date_trigger();
    END IF;
END;
/

