create trigger TRIG_EX10
    before insert or update or delete
    on UTILIZATOR
DECLARE
    v_error_message VARCHAR2(255) := 'Nu s-a intampinat nicio eroare';
    v_error_cod NUMBER := 0;
    exceptia_mea EXCEPTION;
BEGIN
    IF INSERTING THEN   
        IF TO_CHAR(SYSDATE, 'HH24:MI') NOT BETWEEN '09:00' AND '17:00' THEN
            v_error_message := 'Nu puteti sa inserati date in tabelul utilizator in afara orelor de munca!';
            v_error_cod := -20001;
        END IF;
        INSERT INTO utilizator_info(id_operatie,nume_actiune,data_actiune,nume_utilizator,ora_actiune,exceptii)
        VALUES (SEQ_UT_INFO.NEXTVAL,'INSERTING',CURRENT_TIMESTAMP,USER,SYSTIMESTAMP,erori_ex10(v_error_message, v_error_cod));
    END IF;

    v_error_message := 'Nu s-a intampinat nicio eroare';
    v_error_cod := 0;

    IF UPDATING THEN   
        IF TO_CHAR (SYSDATE, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') IN ('THU')  THEN
            v_error_message := 'Nu puteti sa actualizati datele in ziua de JOI';
            v_error_cod := -20002;
        END IF;
        INSERT INTO utilizator_info(id_operatie,nume_actiune,data_actiune,nume_utilizator,ora_actiune,exceptii)
        VALUES (SEQ_UT_INFO.NEXTVAL,'UPDATING',CURRENT_TIMESTAMP,USER,SYSTIMESTAMP,erori_ex10(v_error_message, v_error_cod));
    END IF;

    v_error_message := 'Nu s-a intampinat nicio eroare';
    v_error_cod := 0;

    IF DELETING THEN 
         IF USER!='C##DARIAPIRVULESCU18' THEN
            v_error_message := 'Nu aveti drepturi sa stergeti acest user';
            v_error_cod := -20003;
         END IF;
        INSERT INTO utilizator_info(id_operatie,nume_actiune,data_actiune,nume_utilizator,ora_actiune,exceptii)
        VALUES ( SEQ_UT_INFO.NEXTVAL,'DELETING',CURRENT_TIMESTAMP,USER,SYSTIMESTAMP,erori_ex10(v_error_message, v_error_cod));
    END IF;

    IF v_error_cod != 0 THEN
        RAISE exceptia_mea;
    END IF;
     DBMS_OUTPUT.PUT_LINE('S-a declansat triggerul');
    EXCEPTION
    WHEN exceptia_mea THEN
        RAISE_APPLICATION_ERROR(-20345, 'S-au produs 1 sau mai multe exceptii. Verifica tabelul utilizator_info pentru a vedea!');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(SQLCODE, SQLERRM);
END;
/

